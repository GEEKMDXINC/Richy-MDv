<p align="center">  
  <a href="https://whatsapp.com/channel/0029VaWQOHsFSAsv3SD3dJ3a">
    <img alt="RICHY" height="300" src="https://telegra.ph/file/782e3cbe7c157e425e98a.jpg">
    <h1 align="center">RICHY-MD</h1>
  </a>
</p>
<p align="center">
<a href="https://github.com/GEEKMD099"><img title="Author" src="https://img.shields.io/badge/GEEKMD099-black?style=for-the-badge&logo=Github"></a> <a href="https://whatsapp.com/channel/0029VaWQOHsFSAsv3SD3dJ3a"><img title="Author" src="https://img.shields.io/badge/CHANNEL-black?style=for-the-badge&logo=whatsapp"></a> <a href="https://wa.me/237620857930"><img title="Author" src="https://img.shields.io/badge/CHAT US-black?style=for-the-badge&logo=whatsapp"></a>
<a href="https://chat.whatsapp.com/FRQiuFWlYJ3Jolx7OACtKo"><img title="Author" src="https://img.shields.io/badge/SUPPORT GC-black?style=for-the-badge&logo=whatsapp"></a>
<a href="https://t.me/@ednut_x"><img    title="Author" src="https://img.shields.io/badge/CHAT ME-black?style=for-the-badge&logo=Telegram"></a>
<p/>
<p align="center">
<a href="https://github.com/GEEKMD099?tab=followers"><img title="Followers" src="https://img.shields.io/github/followers/GEEKMD099?label=Followers&style=social"></a>
<a href="https://github.com/GEEKMD099/Richy-MD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/GEEKMDO99/Richy-MD?&style=social"></a>
<a  href="https://github.com/GEEKMDO99/Richy-MD/network/members"><img title="Fork" src="https://img.shields.io/github/forks/GEEKMDO99/Richy-MD?style=social"></a>
<a href="https://github.com/GEEKMD099/Richy-MD/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/GEEKMD099/RICHY-MD?label=Watching&style=social"></a>
</p>

####  
RICHY-MD- Simple Multi Device whatsapp bot.

***

#### SETUP

1. Fork the repo
    <br>
<a href='https://github.com/GEEKMD099/Richy-MD/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork Repo-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a> <br>

<h2><strong>Use paring code QR doe's not work for a moment</strong></h2>

2. Get Session ID (PAIRING)
    <br>
<a href='https://geek-paring-code.onrender.com/pair' target="_blank"><img alt='SESSION ID' src='https://img.shields.io/badge/Session_id-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>


3. Get Session ID (SCAN QR)
    <br>
<a href='https://geek-paring-code.onrender.com' target="_blank"><img alt='SESSION ID' src='https://img.shields.io/badge/Session_id-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>


#### DEPLOY TO HEROKU

1. If You don't have an account in Heroku. Create a account.
    <br>
<p align="center"><a href="https://signup.heroku.com"> <img src="https://img.shields.io/badge/heroku%20Account-blue?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

2. If you Have Heroku Deploy Now
    <br>
<p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/GEEKMD099/Richy-MD"> <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy to Heroku>"/></a></p>

```
Make Sure Run this on a Heroku Teams Not Personal Heroku, I recommed using it Eco Dynos too.
```

#### DEPLOY TO KOYEB

1. if you don't have a koyeb account. Create an account.
   <br>
   <p align="center"><a href="https://app.koyeb.com/auth/signup"> <img src="https://img.shields.io/badge/Koyeb account-blue?style=for-the-badge&logo=koyeb" width="220" height="38.45"/></a></p>

2. Deploy on Koyeb
   <br>
   <p align="center"><a href="https://app.koyeb.com/apps/deploy?type=git&repository=github.com/GEEKMD099/Richy-MD&branch=main&env[SESSION_ID]&env[OWNER_NUMBER]=237620857930&env[MONGODB_URI]&&env[OWNER_NAME]=richy&env[KOYEB_API]&env[PREFIX]=.&env[WAPRESENCE]&env[AUTO_READ_STATUS]=false&env[DISABLE_PM]=false&env[PACK_AUTHER]=whatsapp+bot&env[PACK_NAME]=richy+MD&env[STYLE]=0&env[MODE]=private&env[READ_MESSAGE]=false&env[THEME]=Whatsappbot&env[WARN_COUNT]=3&env[BLOCK_JID]=null&env[TIME_ZONE]=Africa/Lagos&name=richy-md&env[KOYEB_NAME]=richy-md&env[SUDO]=null&env[THUMB_IMAGE]=https://telegra.ph/file/782e3cbe7c157e425e98a.jpg"> <img src="https://www.koyeb.com/static/images/deploy/button.svg" width="380" height="38.45""/></a></p>

#### DEPLOY TO RAILWAY

1. If You don't have an account On Railway. Create a account.
    <br>
<p align="center"><a href="https://railway.app"> <img src="https://img.shields.io/badge/RailWay%20Account-blue?style=for-the-badge&logo=Railway" width="220" height="38.45"/></a></p>

 - Fork and star this repo.
- Now head towards https://railway.app/new, select Deploy from repo.
- Now select the forked repository, select branch.
- Now go to <b>Variables</b> and add variable listed below.
   - DATABASE_URL, SESSION_ID, REMOVEBG_KEY, PREFIX
- Go to <b>Deployments</b> and wait for deplyment to complete.
- and you're good to go.
  

- Star ⭐ the repo if you like RICHY-MD.

   
## WARNING
- This bot is not made by `WhatsApp Inc.` So misusing the bot might `ban` your `WhatsApp account!`(Though your WhatsApp account can be unbanned only once.)
- I am not responsible for banning your account.
- Use at your own risk by keeping this warning in mind.
